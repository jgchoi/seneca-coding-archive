
<p>Following is the information received from add.php</p>
<pre><?php print_r ($_POST)?></pre>
