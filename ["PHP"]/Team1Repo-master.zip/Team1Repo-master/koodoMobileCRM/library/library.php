<?php
//Debuging purpose
error_reporting(-1);

//Library Include Files

include("models.php");
include("menu.php");
include("header.php");
include("footer.php");
include_once("DBLink.php");
?>