<?php
	header("location:employeeManagementModule/login.php");
?>