﻿
// Entity body data, can be used in Fiddler

// Artist at the top
// Album down below

var artist22 =
    {
        "ArtistId": 22,
        "Name": "Led Zeppelin"
    };

var artistNew =
    {
        "Name": "Tim McGraw"
    };

var albumNew1 =
    {
        "ArtistId": 276,
        "Title": "Two Lanes of Freedom"
    };

var albumNew2 =
    {
        "ArtistId": 276,
        "Title": "Sundown Heaven Town"
    };

var albumEdit = 
    {
        "AlbumId": 349,
        "Title": "Humble and Kind"
    };
