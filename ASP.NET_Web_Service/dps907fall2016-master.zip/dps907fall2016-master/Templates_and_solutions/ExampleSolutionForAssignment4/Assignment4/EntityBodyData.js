﻿
var guitar =
    {
        "Category": "Acoustic guitar",
        "ManufacturerName": "Art & Lutherie",
        "InstrumentName": "Spruce Dreadnaught",
        "ModelCode": "13982",
        "MSRP": 359
    };

var drum =
    {
        "Category": "Acoustic drums",
        "ManufacturerName": "Pearl",
        "InstrumentName": "Pearl Export 5-Piece Drum Kit with Hardware",
        "ModelCode": "EXX725C21",
        "MSRP": 929
    };

var violin =
    {
        "Category": "Violin",
        "ManufacturerName": "Leon Aubert",
        "InstrumentName": "Violin Outfit 1/2 Model #50",
        "ModelCode": "16585",
        "MSRP": 340
    };
