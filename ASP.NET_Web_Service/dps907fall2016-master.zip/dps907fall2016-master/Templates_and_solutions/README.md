### Templates and solutions

This folder has project templates that you can use.  

In the near future, it will also have some pre-built solutions for scenarios (e.g. security), and example solutions for assignments.  

**Web service project v2**

Adds several useful features to the "version 1" project template, which were covered in the past several weeks:  
* Media type formatter for byte-oriented content
* HTTP OPTIONS handler
* Hypermedia-aware link relations generator
* Root (entry point) controller to handle requests to /api
* Web API Help Page configuration
* Minor improvement for exceptions/errors

Copy the zip file to the following folder. Do NOT un-zip the file - leave it as-is:  
%userprofile%\Documents\Visual Studio 2015\Templates\ProjectTemplates\Visual C#\Web  

**Web service project v1**

Enables you to learn web service design and coding techniques, without the burden of creating data.  

Includes a sample database with many tables and hundreds of data rows, and:
* Entity Framework
* AutoMapper
* Manager class

Copy the zip file to the following folder. Do NOT un-zip the file - leave it as-is:  
%userprofile%\Documents\Visual Studio 2015\Templates\ProjectTemplates\Visual C#\Web  

**ExampleSolutionForAssignment1**

Example solution for Assignment 1. Implements the specifications, and best practices.  

In Visual Studio, look at the Task List, and go through the comment tokens.  

**AssociationsIntro**

Shows how to handle associated data in a web service, for a one-to-many association.  

Features:
* Employee (one) to Customer (many)
* Get one, and include associated object(s)
* Add new, for the dependent end (e.g. Customer, which requires an Employee identifier)

**ExampleSolutionForAssignment2**

Example solution for Assignment 2. Implements the specifications, and best practices.  

In Visual Studio, look at the Task List, and go through the comment tokens.  
