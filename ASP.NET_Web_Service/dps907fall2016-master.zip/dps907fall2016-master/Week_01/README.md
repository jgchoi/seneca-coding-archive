### Week 1 code examples

**SimpleWebService**

Simple web service, without persistence.  
One entity (Teacher).  
GET and POST HTTP methods are supported.  